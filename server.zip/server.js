import express from 'express';
import dashboardRoutes from './routes/dashboardRoutes.js';

const app = express();
const port = 3000;

app.use(express.json());

// Use the dashboard routes
app.use('/api', dashboardRoutes);

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});