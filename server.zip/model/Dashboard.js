import { DataTypes } from 'sequelize';
import sequelize from '../config/db.js';

const Dashboard = sequelize.define('Dashboard', {
  totalUsers: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  revenue: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
  },
  activeProjects: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  customerSatisfaction: {
    type: DataTypes.DECIMAL(3, 2),
    allowNull: false,
  },
  tasksCompleted: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  teamPerformance: {
    type: DataTypes.DECIMAL(5, 2),
    allowNull: false,
  },
});

export default Dashboard;