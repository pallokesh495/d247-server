import sequelize from '../config/db.js';
import Dashboard from './Dashboard.js';

// Sync the model with the database
await sequelize.sync({ force: false });
console.log('Database & tables synced');

export { Dashboard };